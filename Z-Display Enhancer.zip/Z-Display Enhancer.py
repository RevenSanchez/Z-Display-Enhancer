bl_info = {
    "name": "Z-Display Enhancer",
    "author": "B站_工具人李铁柱",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Add > Mesh > New Object",
    "description": "Adds a new Mesh Object",
    "warning": "",
    "doc_url": "",
    "category": "Add Mesh",
}

import bpy
from bpy.types import Menu, Operator

#class name   function 1
class wireframe(bpy.types.Operator):
    """wireframe"""
    # id name  label name
    bl_idname = "wireframe.id"
    bl_label = "Wireframe"

    def execute(self, context):
        #  main(context)
        bpy.context.space_data.shading.type = 'WIREFRAME'
        bpy.context.space_data.overlay.show_wireframes = False
        bpy.context.space_data.overlay.show_cursor = True
        bpy.context.space_data.overlay.show_floor = True
        bpy.context.space_data.overlay.show_axis_y = True
        bpy.context.space_data.overlay.show_axis_x = True
        bpy.context.space_data.overlay.show_object_origins = True

        return {'FINISHED'}
    
#class name   function 2
class solid(bpy.types.Operator):
    """solid mode"""
    # id name  label name
    bl_idname = "solid.id"
    bl_label = "Solid"

    def execute(self, context):
        #  main(context)
        bpy.context.space_data.shading.type = 'SOLID'
        bpy.context.space_data.overlay.show_wireframes = False
        bpy.context.space_data.overlay.show_cursor = True
        bpy.context.space_data.overlay.show_floor = True
        bpy.context.space_data.overlay.show_axis_y = True
        bpy.context.space_data.overlay.show_axis_x = True
        bpy.context.space_data.overlay.show_object_origins = True

        return {'FINISHED'}
    
#class name   function 3
class rendered(bpy.types.Operator):
    """rendered mode"""
    # id name  label name
    bl_idname = "rendered.id"
    bl_label = "Rendered"

    def execute(self, context):
        #  main(context)
        bpy.context.space_data.shading.type = 'RENDERED'
        bpy.context.space_data.overlay.show_wireframes = False
        bpy.context.space_data.overlay.show_cursor = True
        bpy.context.space_data.overlay.show_floor = True
        bpy.context.space_data.overlay.show_axis_y = True
        bpy.context.space_data.overlay.show_axis_x = True
        bpy.context.space_data.overlay.show_object_origins = True

        return {'FINISHED'}
    
#class name   function 4
class materiel_preview(bpy.types.Operator):
    """materiel_preview"""
    # id name  label name
    bl_idname = "materiel_preview.id"
    bl_label = "Materiel Preview"

    def execute(self, context):
        #  main(context)
        bpy.context.space_data.shading.type = 'MATERIAL'
        bpy.context.space_data.overlay.show_wireframes = False
        bpy.context.space_data.overlay.show_cursor = True
        bpy.context.space_data.overlay.show_floor = True
        bpy.context.space_data.overlay.show_axis_y = True
        bpy.context.space_data.overlay.show_axis_x = True
        bpy.context.space_data.overlay.show_object_origins = True

        return {'FINISHED'}
    
#class name   function 5
class show_wireframe(bpy.types.Operator):
    """show_wireframe in 3d view."""
    # id name  label name
    bl_idname = "show_wireframe.id"
    bl_label = "Show Wireframe"

    def execute(self, context):
        #  main(context)
        bpy.context.space_data.overlay.show_wireframes = True
        bpy.context.space_data.overlay.show_cursor = True
        bpy.context.space_data.overlay.show_floor = True
        bpy.context.space_data.overlay.show_axis_y = True
        bpy.context.space_data.overlay.show_axis_x = True
        bpy.context.space_data.overlay.show_object_origins = True

        return {'FINISHED'}
    
#class name   function 6
class shade_smooth(bpy.types.Operator):
    """let active object smooth"""
    # id name  label name
    bl_idname = "shade_smooth.id"
    bl_label = "Shade Smooth"

    def execute(self, context):
        #  main(context)
        bpy.ops.object.shade_smooth()
        bpy.ops.object.shade_smooth(use_auto_smooth=True)
        bpy.context.space_data.overlay.show_cursor = True
        bpy.context.space_data.overlay.show_floor = True
        bpy.context.space_data.overlay.show_axis_y = True
        bpy.context.space_data.overlay.show_axis_x = True
        bpy.context.space_data.overlay.show_object_origins = True

        return {'FINISHED'}
    
#class name   function 7
class shade_flat(bpy.types.Operator):
    """shade_flat"""
    # id name  label name
    bl_idname = "shade_flat.id"
    bl_label = "Shade Flat"

    def execute(self, context):
        #  main(context)
        bpy.ops.object.shade_flat()
        bpy.context.space_data.overlay.show_cursor = True
        bpy.context.space_data.overlay.show_floor = True
        bpy.context.space_data.overlay.show_axis_y = True
        bpy.context.space_data.overlay.show_axis_x = True
        bpy.context.space_data.overlay.show_object_origins = True

        return {'FINISHED'}
    
#class name   function 8
class hide_floor(bpy.types.Operator):
    """hide floor in 3d view."""
    # id name  label name
    bl_idname = "hide_floor.id"
    bl_label = "Hide Floor"

    def execute(self, context):
        #  main(context)
        bpy.context.space_data.overlay.show_cursor = False
        bpy.context.space_data.overlay.show_floor = False
        bpy.context.space_data.overlay.show_axis_y = False
        bpy.context.space_data.overlay.show_axis_x = False
        bpy.context.space_data.overlay.show_object_origins = False
        return {'FINISHED'}

class VIEW3D_MT_PIE_template(Menu):
    # label 
    bl_label = "shading"

    def draw(self, context):
        layout = self.layout

        pie = layout.menu_pie()
        # id name function 1
        pie.operator("wireframe.id")
        # id name function 2
        pie.operator("solid.id")  
        # id name function 4
        pie.operator("materiel_preview.id")
        # id name function 3
        pie.operator("rendered.id")
        # id name function 5
        pie.operator("show_wireframe.id")
        # id name function 6
        pie.operator("shade_smooth.id")
        # id name function 8
        pie.operator("hide_floor.id")
        # id name function 7
        pie.operator("shade_flat.id")
        
addon_keymaps = []

def register():
    bpy.utils.register_class(VIEW3D_MT_PIE_template)
    # function 1
    bpy.utils.register_class(wireframe)
    # function 2
    bpy.utils.register_class(solid)
    # function 3
    bpy.utils.register_class(rendered)
    # function 4
    bpy.utils.register_class(materiel_preview)
    # function 5
    bpy.utils.register_class(show_wireframe)
    # function 6
    bpy.utils.register_class(shade_smooth)
    # function 7
    bpy.utils.register_class(shade_flat)
    # function 8
    bpy.utils.register_class(hide_floor)
  
    # 注册快捷键
    wm = bpy.context.window_manager
    km = wm.keyconfigs.addon.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'Z', 'PRESS')
    kmi.properties.name = "VIEW3D_MT_PIE_template"
    addon_keymaps.append((km, kmi))


def unregister():
    bpy.utils.unregister_class(VIEW3D_MT_PIE_template)
    # function 1
    bpy.utils.unregister_class(solid)
    # function 2
    bpy.utils.unregister_class(wireframe)
    # function 3
    bpy.utils.unregister_class(rendered)
    # function 4
    bpy.utils.unregister_class(materiel_preview)
    # function 5
    bpy.utils.unregister_class(show_wireframe)
    # function 6
    bpy.utils.unregister_class(shade_smooth)
    # function 7
    bpy.utils.unregister_class(shade_flat)
    # function 8
    bpy.utils.unregister_class(hide_floor)

    # 注销快捷键
    wm = bpy.context.window_manager
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

if __name__ == "__main__":
    register()

    bpy.ops.wm.call_menu_pie(name="VIEW3D_MT_PIE_template")
